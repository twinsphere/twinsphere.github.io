function Header({ currentScreen, onNav, bookmarkActive, onToggleBookmark, syncActive, onToggleSync, onOpenMenu }) {
  const showTwinActions = currentScreen === "overview" || currentScreen === "submodel";
  return (
    <nav style={{
      display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "4px 16px 12px 8px"
    }}>
      <button className="btn icon ghost" onClick={onOpenMenu} aria-label="Open menu"
        style={{ background: "transparent", border: "none", cursor: "pointer", height: 36, width: 36 }}>
        <Icon name="menu" color="var(--accent)" size={22} />
      </button>
      <a onClick={() => onNav("start")} style={{ fontSize: 24, lineHeight: 1, textDecoration: "none", color: "white", cursor: "pointer" }}>
        <span style={{ color: "var(--accent)", fontWeight: 700 }}>twin</span>viewer
      </a>
      <div style={{ fontStyle: "italic", fontSize: 12, color: "#97a4a7", marginTop: 6, marginLeft: 2 }}>
        powered by twinsphere
      </div>
      <div style={{ flex: 1 }} />
      {showTwinActions && (
        <>
          <button className="btn icon ghost" onClick={onToggleBookmark}
            style={{ background: "transparent", border: "none", cursor: "pointer", height: 36, width: 36 }}>
            <Icon name={bookmarkActive ? "bookmark" : "bookmark_border"} outlined={!bookmarkActive} size={20}
              color={bookmarkActive ? "var(--accent)" : "white"} />
          </button>
          <button className="btn icon ghost" onClick={onToggleSync} title="Enable/disable automatic refresh"
            style={{ background: "transparent", border: "none", cursor: "pointer", height: 36, width: 36 }}>
            <span
              key={syncActive ? "on" : "off"}
              style={{
                display: "inline-block",
                animation: `${syncActive ? "tw-sync-start 2s cubic-bezier(0,0,0.2,1)" : "tw-sync-stop 1s cubic-bezier(0,0,0.2,1)"}`,
                color: syncActive ? "var(--success)" : "white",
              }}
            >
              <Icon name="sync" outlined size={20} color={syncActive ? "var(--success)" : "white"} />
            </span>
          </button>
        </>
      )}
    </nav>
  );
}

window.Header = Header;
