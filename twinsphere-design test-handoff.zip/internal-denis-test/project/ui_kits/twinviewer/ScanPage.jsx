function ScanPage({ onResolved }) {
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    // simulate QR being detected after a bit
    const t = setTimeout(() => {
      setLoading(true);
      const t2 = setTimeout(() => onResolved("PWR-PACK-7-2"), 1400);
      return () => clearTimeout(t2);
    }, 1800);
    return () => clearTimeout(t);
  }, []);

  return (
    <div style={{
      display: "flex", flexDirection: "column", height: "100%", alignItems: "center",
      padding: "16px 16px 16px 8px", position: "relative", minHeight: 500
    }}>
      <div style={{
        width: "100%", maxWidth: 720, aspectRatio: "4 / 3",
        background: "linear-gradient(135deg, #0f2226 0%, #1a4048 100%)",
        position: "relative", overflow: "hidden",
      }}>
        {/* simulate the video feed */}
        <div style={{
          position: "absolute", inset: 0,
          backgroundImage: "radial-gradient(circle at 40% 60%, rgba(255,255,255,0.08), transparent 40%), radial-gradient(circle at 75% 30%, rgba(145,196,100,0.06), transparent 50%)",
        }} />
        {/* QR reticle */}
        <div style={{
          position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
          width: 200, height: 200, border: "2px solid rgba(255,255,255,0.5)",
        }}>
          {["tl","tr","bl","br"].map(c => (
            <span key={c} style={{
              position: "absolute",
              [c.startsWith("t") ? "top" : "bottom"]: -2,
              [c.endsWith("l") ? "left" : "right"]: -2,
              width: 36, height: 36,
              borderTop: c.startsWith("t") ? "4px solid var(--accent)" : undefined,
              borderBottom: c.startsWith("b") ? "4px solid var(--accent)" : undefined,
              borderLeft: c.endsWith("l") ? "4px solid var(--accent)" : undefined,
              borderRight: c.endsWith("r") ? "4px solid var(--accent)" : undefined,
            }} />
          ))}
        </div>
      </div>

      <div style={{ width: "100%", maxWidth: 720, display: "flex", alignItems: "center", marginTop: 16, marginBottom: 16 }}>
        <Icon name="info" size={20} color="white" />
        <p style={{ fontSize: 14, marginLeft: 8, marginBlock: 0 }}>
          If the scan doesn't work, try reloading the page.
        </p>
      </div>

      {loading && (
        <div style={{
          position: "fixed", inset: 0, background: "rgba(47,73,80,0.5)", zIndex: 40,
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <div style={{
            background: "white", borderRadius: "var(--radius-md)", padding: "16px 32px",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 16, maxWidth: "90%",
          }}>
            <div style={{
              width: 24, height: 24, borderRadius: "50%",
              border: "6px solid var(--accent)", borderRightColor: "var(--primary)",
              animation: "tw-spin 1s linear infinite",
            }} />
            <p style={{ color: "var(--primary)", fontWeight: 600, margin: 0 }}>
              Code recognized, trying to resolve Digital Twin...
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

window.ScanPage = ScanPage;
