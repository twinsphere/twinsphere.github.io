function StartPage({ bookmarks, onOpenScan, onOpenTwin }) {
  return (
    <div style={{
      minHeight: "100%", display: "flex", flexDirection: "column", alignItems: "center", gap: 40, padding: "24px 32px 24px 24px"
    }}>
      <a
        onClick={onOpenScan}
        aria-label="Scan QR Code"
        style={{
          display: "flex", flexDirection: "column", alignItems: "center", gap: 12,
          background: "var(--primary)", color: "white",
          borderRadius: 16, padding: 32,
          boxShadow: "0 4px 6px -1px rgba(0,0,0,0.3), 0 2px 4px -2px rgba(0,0,0,0.25)",
          cursor: "pointer", transition: "opacity 200ms",
        }}
        onMouseDown={(e) => (e.currentTarget.style.opacity = "0.9")}
        onMouseUp={(e) => (e.currentTarget.style.opacity = "1")}
        onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
      >
        <Icon name="qr_code" size={64} color="white" />
        <span style={{ fontSize: 18, fontWeight: 600 }}>Scan QR Code</span>
      </a>

      <section style={{ width: "100%", maxWidth: 720 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <h2 style={{ color: "var(--accent)", fontSize: 14, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.04em", margin: 0 }}>
            Recent Bookmarks
          </h2>
          <button
            disabled={!bookmarks.length}
            style={{
              display: "flex", alignItems: "center", gap: 6, color: bookmarks.length ? "white" : "var(--gray)",
              textDecoration: "underline", background: "none", border: "none", cursor: "pointer", fontSize: 14,
              opacity: bookmarks.length ? 1 : 0.5,
            }}
          >
            <Icon name="bookmark" size={16} color={bookmarks.length ? "white" : "var(--gray)"} />
            Open Bookmarks
          </button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {bookmarks.length === 0 ? (
            <p style={{ fontStyle: "italic", color: "var(--gray)", margin: 0 }}>
              You currently have no bookmarks. Visit a digital twin to add it as a bookmark.
            </p>
          ) : (
            bookmarks.map((b) => (
              <a
                key={b.id}
                onClick={() => onOpenTwin(b.parsedId)}
                style={{
                  background: "var(--primary)", borderRadius: "var(--radius-md)",
                  padding: "12px 16px", display: "flex", alignItems: "center", gap: 12, cursor: "pointer",
                  transition: "opacity 200ms",
                }}
                onMouseOver={(e) => (e.currentTarget.style.opacity = "0.92")}
                onMouseOut={(e) => (e.currentTarget.style.opacity = "1")}
              >
                <Icon name="bookmark" size={20} color="var(--accent)" />
                <div style={{ minWidth: 0 }}>
                  <div style={{ color: "var(--accent)", fontWeight: 400 }}>{b.title}</div>
                  {b.description && <div style={{ fontSize: 14, opacity: 0.75 }}>{b.description}</div>}
                </div>
              </a>
            ))
          )}
        </div>
      </section>
    </div>
  );
}

window.StartPage = StartPage;
