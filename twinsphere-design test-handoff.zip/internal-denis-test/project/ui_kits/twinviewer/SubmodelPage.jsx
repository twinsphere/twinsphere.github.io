function PropertyRow({ label, children, definition }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{ padding: "6px 12px 8px", marginTop: 4 }}>
      <div
        onClick={() => definition && setOpen((v) => !v)}
        style={{ color: "var(--accent)", fontSize: 13, fontWeight: 700, display: "flex", gap: 6, alignItems: "center", cursor: definition ? "pointer" : "default" }}
      >
        {label}
        {definition && <Icon name="arrow_drop_down" size={18} color="var(--accent)"
          className={open ? "rot" : ""} />}
      </div>
      {definition && open && (
        <div style={{ fontStyle: "italic", color: "var(--gray)", marginTop: 4, fontSize: 13 }}>
          {definition}
        </div>
      )}
      <div style={{ fontSize: 14, marginTop: 2 }}>{children}</div>
    </div>
  );
}

function CollectionBlock({ title, children, defaultOpen = true }) {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <div style={{ display: "flex", gap: 4, marginTop: 4 }}>
      <div style={{ width: 8, background: "var(--primary)", borderRadius: 6, minHeight: "100%" }} />
      <div style={{ flex: 1 }}>
        <button
          onClick={() => setOpen((v) => !v)}
          style={{
            background: "var(--primary)", border: "none", borderRadius: 6,
            width: "100%", height: 44, color: "white",
            padding: "0 12px", fontSize: 16, textAlign: "left",
            display: "flex", alignItems: "center", gap: 8, cursor: "pointer",
          }}
        >
          <Icon name="expand_more" size={20} className={open ? "rot" : ""} />
          {title}
        </button>
        {open && <div>{children}</div>}
      </div>
    </div>
  );
}

function SubmodelPage({ routeKey, twin, onGoOverview }) {
  // Render something different per route using the twin data.
  const routeContent = {
    nameplate: (
      <>
        <CollectionBlock title="Asset Information">
          <PropertyRow label="Asset Kind" definition="Describes if an element is a type or an instance.">Instance</PropertyRow>
          <PropertyRow label="Global Asset ID">urn:voltera:powerpack:{twin.id}</PropertyRow>
          <PropertyRow label="Version">1.2.0</PropertyRow>
        </CollectionBlock>
        <CollectionBlock title="Manufacturer">
          <PropertyRow label="Manufacturer name">{twin.nameplate.manufacturerName}</PropertyRow>
          <PropertyRow label="Manufacturer identifier">{twin.nameplate.manufacturerId}</PropertyRow>
          <PropertyRow label="Date of manufacture">{twin.nameplate.dateOfManufacture}</PropertyRow>
        </CollectionBlock>
        <CollectionBlock title="Serial & Article">
          <PropertyRow label="Serial number">{twin.nameplate.serialNumber}</PropertyRow>
          <PropertyRow label="Article number">{twin.techdata.manufacturerArticleNumber}</PropertyRow>
          <PropertyRow label="Operator identifier">{twin.nameplate.operatorId}</PropertyRow>
        </CollectionBlock>
      </>
    ),
    technicaldata: (
      <>
        <CollectionBlock title="Electrical">
          <PropertyRow label="Nominal voltage" definition="Nominal output voltage under standard load.">{twin.techdata.nominalVoltage.value} {twin.techdata.nominalVoltage.unit}</PropertyRow>
          <PropertyRow label="Min voltage">{twin.techdata.minVoltage.value} {twin.techdata.minVoltage.unit}</PropertyRow>
          <PropertyRow label="Max voltage">{twin.techdata.maxVoltage.value} {twin.techdata.maxVoltage.unit}</PropertyRow>
          <PropertyRow label="Rated capacity">{twin.techdata.ratedCapacity.value} {twin.techdata.ratedCapacity.unit}</PropertyRow>
          <PropertyRow label="Max. permitted battery power">{twin.techdata.maxPermittedBatteryPower.value} {twin.techdata.maxPermittedBatteryPower.unit}</PropertyRow>
        </CollectionBlock>
        <CollectionBlock title="Environmental">
          <PropertyRow label="Temperature range">
            {twin.techdata.tempRangeLower.value} {twin.techdata.tempRangeLower.unit} to {twin.techdata.tempRangeUpper.value} {twin.techdata.tempRangeUpper.unit}
          </PropertyRow>
          <PropertyRow label="Capacity threshold exhaustion">{twin.techdata.capThreshold.value} {twin.techdata.capThreshold.unit}</PropertyRow>
        </CollectionBlock>
      </>
    ),
    carbonfootprint: (
      <>
        <CollectionBlock title="Product Carbon Footprint">
          {twin.pcf.map((p) => (
            <PropertyRow key={p.name} label={p.name}>{p.value} CO2eq</PropertyRow>
          ))}
        </CollectionBlock>
        <div style={{ marginTop: 16 }}>
          <PcfDonut pcf={twin.pcf} />
        </div>
      </>
    ),
    materialcomposition: (
      <>
        <div style={{ marginBottom: 16 }}>
          <MaterialsBar materials={twin.materials} />
        </div>
        <CollectionBlock title="Battery materials">
          {twin.materials.map((m) => (
            <PropertyRow key={m.name} label={m.name}>{m.mass} kg</PropertyRow>
          ))}
        </CollectionBlock>
        <CollectionBlock title="Hazardous" defaultOpen={false}>
          <PropertyRow label="Hazardous material">{twin.hazardousMaterial}</PropertyRow>
        </CollectionBlock>
      </>
    ),
    productcondition: (
      <>
        <CollectionBlock title="Status">
          <PropertyRow label="State of charge">{twin.prodcond.stateOfCharge.value} {twin.prodcond.stateOfCharge.unit}</PropertyRow>
          <PropertyRow label="Remaining capacity">{twin.prodcond.remainingCap.value} {twin.prodcond.remainingCap.unit}</PropertyRow>
          <PropertyRow label="Number of full cycles">{twin.prodcond.numberOfFullCycles}</PropertyRow>
        </CollectionBlock>
        <CollectionBlock title="Events">
          <PropertyRow label="Last negative event">{twin.prodcond.negativeEventText}</PropertyRow>
          <PropertyRow label="Negative event date">{twin.prodcond.negativeEventDate}</PropertyRow>
        </CollectionBlock>
      </>
    ),
    handoverdoc: (
      <CollectionBlock title="Documents">
        <PropertyRow label="User manual">Voltera_PowerPack7.2_Manual.pdf</PropertyRow>
        <PropertyRow label="Installation guide">Voltera_PowerPack7.2_Install.pdf</PropertyRow>
        <PropertyRow label="Declaration of conformity">CE_DoC_2024.pdf</PropertyRow>
      </CollectionBlock>
    ),
    circularity: (
      <CollectionBlock title="End-of-life & recyclability">
        <PropertyRow label="Recyclability rate">92 %</PropertyRow>
        <PropertyRow label="Disassembly instructions available">Yes</PropertyRow>
        <PropertyRow label="Take-back contact">recycle@voltera.example</PropertyRow>
      </CollectionBlock>
    ),
  }[routeKey] ?? <div style={{ padding: 16, color: "var(--gray)" }}>No content.</div>;

  return (
    <div style={{ padding: "0 16px 32px 8px" }}>
      <AccentButton icon="dashboard" onClick={onGoOverview}>Go to Overview</AccentButton>
      <div style={{ height: 16 }} />
      {routeContent}
    </div>
  );
}

window.SubmodelPage = SubmodelPage;
