function App() {
  const [screen, setScreen] = React.useState("start"); // start | scan | overview | submodel
  const [route, setRoute] = React.useState("overview"); // submodel route key
  const [bookmarksState, setBookmarksState] = React.useState(bookmarks);
  const [bookmarkActive, setBookmarkActive] = React.useState(true);
  const [syncActive, setSyncActive] = React.useState(false);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [language, setLanguage] = React.useState("en");
  const [toast, setToast] = React.useState(null);

  function showToast(msg, type = "info") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2500);
  }

  function handleNav(target) {
    setScreen(target);
    if (target === "overview") setRoute("overview");
  }

  function handleOpenTwin(id) { setScreen("overview"); setRoute("overview"); }
  function handleOpenScan() { setScreen("scan"); }
  function handleResolved(id) { setScreen("overview"); setRoute("overview"); }
  function handleNavSubmodel(key) { setScreen("submodel"); setRoute(key); }
  function handleToOverview() { setScreen("overview"); setRoute("overview"); }

  function toggleBookmark() {
    setBookmarkActive((b) => {
      showToast(!b ? "Bookmark Added" : "Bookmark Removed", "success");
      return !b;
    });
  }
  function toggleSync() {
    setSyncActive((s) => {
      showToast(!s ? "Automatic Refresh enabled" : "Automatic Refresh disabled", "info");
      return !s;
    });
  }

  return (
    <div style={{
      minHeight: "100vh", background: "var(--bg-page)", color: "white",
      fontFamily: "var(--font-sans)",
    }}>
      <div style={{ maxWidth: 1024, margin: "0 auto", display: "flex", flexDirection: "column", minHeight: "100vh" }}>
        <Header
          currentScreen={screen}
          onNav={handleNav}
          bookmarkActive={bookmarkActive}
          onToggleBookmark={toggleBookmark}
          syncActive={syncActive}
          onToggleSync={toggleSync}
          onOpenMenu={() => setMenuOpen(true)}
        />

        {screen === "overview" || screen === "submodel" ? (
          <div style={{ padding: "0 16px 0 8px" }}>
            <SubmodelNav active={route} routes={submodelRoutes} onNav={(k) => {
              if (k === "overview") handleToOverview(); else handleNavSubmodel(k);
            }} />
            <hr style={{ border: "none", borderTop: "2px solid var(--primary)", margin: "0 16px 16px 0" }} />
          </div>
        ) : null}

        <main style={{ flex: 1 }}>
          {screen === "start"    && <StartPage bookmarks={bookmarksState} onOpenScan={handleOpenScan} onOpenTwin={handleOpenTwin} />}
          {screen === "scan"     && <ScanPage onResolved={handleResolved} />}
          {screen === "overview" && <OverviewPage twin={twinData} onNavSubmodel={handleNavSubmodel} />}
          {screen === "submodel" && <SubmodelPage routeKey={route} twin={twinData} onGoOverview={handleToOverview} />}
        </main>

        <MenuDrawer
          open={menuOpen}
          onClose={() => setMenuOpen(false)}
          language={language}
          onLanguageChange={setLanguage}
          onNav={handleNav}
        />

        {toast && (
          <div style={{
            position: "fixed", left: 0, right: 0, bottom: 24, display: "flex", justifyContent: "center", zIndex: 60,
            pointerEvents: "none",
          }}>
            <div style={{
              background: toast.type === "success" ? "#54802E" : (toast.type === "alert" ? "#c42e5f" : "#2f4950"),
              border: "2px solid white", borderRadius: 4, padding: "12px 16px", fontWeight: 500,
              fontSize: 14, maxWidth: 400, textAlign: "center",
            }}>
              {toast.msg}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

window.App = App;
