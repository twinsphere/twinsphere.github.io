/** Shared UI primitives for Twinviewer kit */

function Icon({ name, size = 20, color, outlined = false, className = "" }) {
  const cls = outlined ? "material-icons-outlined" : "material-icons";
  return (
    <span
      className={`${cls} ${className}`}
      style={{ fontSize: size, color, lineHeight: 1, verticalAlign: "middle", userSelect: "none" }}
      aria-hidden="true"
    >
      {name}
    </span>
  );
}

function Card({ heading, value, unit, description, icon, wide = false, children }) {
  return (
    <div
      className="tw-card"
      style={{
        background: "var(--bg-raised)",
        borderRadius: "var(--radius-md)",
        padding: "16px",
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: "4px",
        gridColumn: wide ? "span 2" : undefined,
      }}
    >
      {heading && <span className="card-heading">{heading}</span>}
      {children ? children : (
        <>
          {value !== undefined && (
            <span className="card-data">
              {value}{unit ? <span className="card-unit" style={{ marginLeft: 4 }}>{unit}</span> : null}
            </span>
          )}
          {description && <span className="card-description">{description}</span>}
        </>
      )}
      {icon && (
        <span style={{ position: "absolute", right: 14, bottom: 12, color: "white", opacity: 0.85 }}>
          <Icon name={icon} size={40} />
        </span>
      )}
    </div>
  );
}

function ListRow({ label, children }) {
  return (
    <div style={{
      display: "flex", justifyContent: "space-between", alignItems: "baseline",
      padding: "10px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: 14, gap: 16
    }}>
      <span style={{ color: "var(--fg-2)" }}>{label}</span>
      <span style={{ color: "white", textAlign: "right" }}>{children}</span>
    </div>
  );
}

function ChartFrame({ title, children }) {
  return (
    <div style={{
      background: "var(--bg-raised)", borderRadius: "var(--radius-xs)",
      padding: 8, display: "grid", gridTemplateRows: "max-content max-content max-content", minWidth: 0
    }}>
      <span className="eyebrow" style={{ marginBottom: 4 }}>{title}</span>
      {children}
    </div>
  );
}

function AccentButton({ icon, children, onClick }) {
  return (
    <button
      onClick={onClick}
      className="btn icon-button md"
      style={{
        background: "var(--primary)",
        color: "white",
        border: "none",
        borderRadius: "var(--radius-md)",
        padding: "0 14px",
        height: 44,
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        fontSize: 16,
        cursor: "pointer",
      }}
    >
      {icon && <Icon name={icon} size={20} />}
      {children}
    </button>
  );
}

function Divider() {
  return <hr style={{ border: "none", borderTop: "1px solid var(--primary)", margin: "0 16px 16px 0" }} />;
}

Object.assign(window, { Icon, Card, ListRow, ChartFrame, AccentButton, Divider });
