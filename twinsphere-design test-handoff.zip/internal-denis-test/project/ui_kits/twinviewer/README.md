# Twinviewer UI Kit (React)

Recreation of the Twinspector / Twinviewer PWA surface in React. Built off the Angular source in `twinspector/ui/src/`.

## Files

- `index.html` — clickable prototype. Opens on the **Start** screen. Tap "Scan QR Code" to see the scanner screen, or a bookmark to open the Digital Twin overview. From the overview, the submodel nav takes you to Nameplate, Technical Data, etc.
- `App.jsx` — app shell, header, toast, and route state.
- `Header.jsx` — wordmark + menu, bookmark toggle, sync toggle (with rotating icon animation).
- `MenuDrawer.jsx` — mobile left-drawer / desktop dropdown menu.
- `StartPage.jsx` — QR scan hero CTA + recent bookmarks list + empty state.
- `ScanPage.jsx` — camera viewport placeholder + resolver loading state.
- `OverviewPage.jsx` — Digital Twin / Battery Passport overview: product title, manufacturer, stat cards, material bar, PCF donut, tech data list, markings, submodel nav grid.
- `SubmodelPage.jsx` — generic submodel detail page with expandable property tree.
- `Bits.jsx` — small shared primitives: Card, Icon, ListRow, etc.
- `data.js` — fake fixture data for one battery twin.

Kit conventions:
- Colors and type pulled from root-level `colors_and_type.css`.
- Icons via Material Icons webfont (closest 1:1 match to `@ng-icons/material-icons/*` used in source).
- No real routing — single SPA state switch in `App.jsx`.
