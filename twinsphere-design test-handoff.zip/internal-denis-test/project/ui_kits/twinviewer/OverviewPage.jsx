function SubmodelNav({ active, routes, onNav }) {
  const [open, setOpen] = React.useState(false);
  const activeLabel = routes.find((r) => r.key === active)?.label ?? "Overview";

  return (
    <div>
      <h3 style={{ margin: "16px 0" }}>
        <button
          onClick={() => setOpen((v) => !v)}
          style={{
            width: "100%", textAlign: "left", cursor: "pointer",
            display: "flex", alignItems: "center", background: "none", border: "none",
            color: "white", fontSize: 20, fontWeight: 300, textTransform: "uppercase",
          }}
        >
          <Icon name="recent_actors" size={20} color="white" className="" />
          <span style={{ marginLeft: 16, flex: 1 }}>{activeLabel}</span>
        </button>
      </h3>
      {open && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 16 }}>
          {routes.map((r) => (
            <a key={r.key} onClick={() => { setOpen(false); onNav(r.key); }}
              style={{
                marginLeft: 44, fontSize: 16, cursor: "pointer", color: active === r.key ? "var(--accent)" : "white",
                textTransform: "uppercase",
              }}>
              {r.label}
            </a>
          ))}
          <a style={{ marginLeft: 44, fontSize: 16, color: "rgba(255,255,255,0.6)", textTransform: "uppercase" }}>Dummy 1</a>
          <a style={{ marginLeft: 44, fontSize: 16, color: "rgba(255,255,255,0.6)", textTransform: "uppercase" }}>Dummy 2</a>
        </div>
      )}
    </div>
  );
}

function MaterialsBar({ materials }) {
  const total = materials.reduce((a, b) => a + b.mass, 0);
  const sorted = [...materials].sort((a, b) => b.mass - a.mass);
  return (
    <ChartFrame title="Material Composition">
      <div style={{
        display: "flex", height: 40, margin: 8, borderRadius: 2, overflow: "hidden", border: "1px solid white"
      }}>
        {sorted.map((m, i) => (
          <div key={m.name} style={{
            flex: m.mass, background: materialsColorList[i % materialsColorList.length],
            borderRight: i < sorted.length - 1 ? "1px solid white" : "none",
          }} />
        ))}
      </div>
      <div style={{ margin: 8 }}>
        {sorted.map((m, i) => (
          <div key={m.name} style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 4, fontSize: 14 }}>
            <span style={{
              display: "inline-block", width: 16, height: 16, border: "2px solid white",
              borderRadius: 2, background: materialsColorList[i % materialsColorList.length],
            }} />
            <span>{m.name} ({Math.round((m.mass / total) * 100)} %)</span>
          </div>
        ))}
      </div>
    </ChartFrame>
  );
}

function PcfDonut({ pcf }) {
  const total = pcf.reduce((a, b) => a + b.value, 0);
  // build the stroke-dasharray segments around a circle
  const radius = 70;
  const circ = 2 * Math.PI * radius;
  let offset = 0;
  const segments = pcf.map((p, i) => {
    const frac = p.value / total;
    const seg = {
      color: pcfColorList[i % pcfColorList.length],
      dash: `${circ * frac - 6} ${circ}`,
      offset: -offset,
    };
    offset += circ * frac;
    return seg;
  });
  return (
    <ChartFrame title="Carbon Footprint">
      <div style={{ position: "relative", height: 240, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <svg viewBox="-100 -100 200 200" width="200" height="200" style={{ transform: "rotate(-90deg)" }}>
          {segments.map((s, i) => (
            <circle key={i} r={radius} fill="none"
              stroke={s.color} strokeWidth={26}
              strokeDasharray={s.dash} strokeDashoffset={s.offset} />
          ))}
        </svg>
        <div style={{ position: "absolute", textAlign: "center" }}>
          <div style={{ fontSize: 42, color: "white", lineHeight: 1 }}>{total}</div>
          <div style={{ fontSize: 14, color: "white" }}>CO<sub>2</sub>eq</div>
        </div>
      </div>
      <div style={{ margin: 8 }}>
        {pcf.map((p, i) => (
          <div key={p.name} style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 4, fontSize: 14 }}>
            <span style={{
              display: "inline-block", width: 16, height: 16, border: "2px solid white",
              borderRadius: 2, background: pcfColorList[i % pcfColorList.length],
            }} />
            <span>{p.name} ({Math.round((p.value / total) * 100)} %)</span>
          </div>
        ))}
      </div>
    </ChartFrame>
  );
}

function OverviewPage({ twin, onNavSubmodel }) {
  const { techdata, nameplate, prodcond, pcf, materials, hazardousMaterial } = twin;
  const totalPcf = pcf.reduce((a, b) => a + b.value, 0);

  const techListData = [
    ["Battery mass", `${techdata.batteryMass.value} ${techdata.batteryMass.unit}`],
    ["Nominal voltage", `${techdata.nominalVoltage.value} ${techdata.nominalVoltage.unit}`],
    ["Min voltage", `${techdata.minVoltage.value} ${techdata.minVoltage.unit}`],
    ["Max voltage", `${techdata.maxVoltage.value} ${techdata.maxVoltage.unit}`],
    ["Rated capacity", `${techdata.ratedCapacity.value} ${techdata.ratedCapacity.unit}`],
    ["Max. permitted battery power", `${techdata.maxPermittedBatteryPower.value} ${techdata.maxPermittedBatteryPower.unit}`],
    ["Temperature range", `${techdata.tempRangeLower.value} ${techdata.tempRangeLower.unit} to ${techdata.tempRangeUpper.value} ${techdata.tempRangeUpper.unit}`],
    ["Capacity threshold exhaustion", `${techdata.capThreshold.value} ${techdata.capThreshold.unit}`],
  ];

  const inlineData = [
    ["unique facility identifier", nameplate.facilityId],
    ["manufacturer identifier", nameplate.manufacturerId],
    ["operator identifier", nameplate.operatorId],
    ["warranty period", techdata.warrantyPeriod],
    ["expected lifetime in years", techdata.expectedLifetimeInCalendarYears],
    ["date of manufacture", nameplate.dateOfManufacture],
  ];

  const submodelCells = [
    { key: "nameplate", label: "Digital Nameplate" },
    { key: "handoverdoc", label: "Handover Documentation" },
    { key: "carbonfootprint", label: "Carbon Footprint" },
    { key: "technicaldata", label: "Technical Data" },
    { key: "productcondition", label: "Product Condition" },
    { key: "materialcomposition", label: "Material Composition" },
    { key: "circularity", label: "Circularity" },
  ];

  return (
    <div style={{ padding: "0 16px 32px 8px" }}>
      {/* Product title block */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 16, marginBottom: 16 }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 500, color: "var(--accent)" }}>
            {techdata.batteryCategory}
          </div>
          <div style={{ fontSize: 20, fontWeight: 300, color: "var(--accent)" }}>
            {techdata.manufacturerProductDesignation}
          </div>
        </div>

        <div>
          <div style={{ fontWeight: 500, fontSize: 16, marginBottom: 8 }}>{nameplate.manufacturerName}</div>
          <div style={{ fontSize: 14 }}>
            <span style={{ color: "var(--gray)", marginRight: 8, textTransform: "uppercase" }}>Art. nr.</span>
            <span>{techdata.manufacturerArticleNumber}</span>
          </div>
          <div style={{ fontSize: 14 }}>
            <span style={{ color: "var(--gray)", marginRight: 8, textTransform: "uppercase" }}>Serial nr.</span>
            <span>{nameplate.serialNumber}</span>
          </div>
          <div style={{ fontSize: 14 }}>
            <span style={{ color: "var(--gray)", marginRight: 8, textTransform: "uppercase" }}>Overall CO2 emission</span>
            <span>{totalPcf} CO2eq</span>
          </div>
          <div style={{ fontSize: 14 }}>
            <span style={{ color: "var(--gray)", marginRight: 8, textTransform: "uppercase" }}>Lifecycle state</span>
            <span>{nameplate.lifeCycleStage}</span>
          </div>
        </div>
      </div>

      {/* Condition card grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 16 }}>
        <Card wide heading="Current Lifetime in Service" icon="schedule" description={nameplate.dateOfPuttingIntoService}>
          <span className="card-heading">Current Lifetime in Service</span>
          <span className="card-data">
            {nameplate.lifeTime[0]} <span className="card-unit">years</span>{" "}
            {nameplate.lifeTime[1]} <span className="card-unit">months</span>{" "}
            {nameplate.lifeTime[2]} <span className="card-unit">days</span>
          </span>
          <span className="card-description">{nameplate.dateOfPuttingIntoService}</span>
        </Card>
        <Card heading="State of Charge" value={prodcond.stateOfCharge.value} unit={prodcond.stateOfCharge.unit}
          description={prodcond.chargeLastUpdate} icon="battery_5_bar" />
        <Card heading="Remaining Capacity" value={prodcond.remainingCap.value} unit={prodcond.remainingCap.unit}
          description={prodcond.remainingLastUpdate} icon="battery_charging_full" />
        <Card wide heading="Number of Full Cycles" value={prodcond.numberOfFullCycles}
          description={`Expected: ${techdata.expectedNumberOfCycles}`} icon="ev_station" />
        <Card wide heading="Last Negative Event" icon="event_busy">
          <span className="card-heading">Last Negative Event</span>
          <span className="card-data" style={{ fontSize: 18 }}>{prodcond.negativeEventText}</span>
          <span className="card-description">{prodcond.negativeEventDate}</span>
        </Card>
        <Card wide heading="Time Extreme Temp Charging" icon="device_thermostat">
          <span className="card-heading">Time Extreme Temp Charging</span>
          <div style={{ display: "flex", gap: 16, alignItems: "flex-end", marginTop: 4 }}>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 4, minWidth: 120 }}>
              <Icon name="wb_sunny" size={18} color="white" />
              <span style={{ fontSize: 24, color: "white" }}>{prodcond.timeExtremeHigh.value}</span>
              <span className="card-unit">{prodcond.timeExtremeHigh.unit}</span>
            </div>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 4 }}>
              <Icon name="ac_unit" size={18} color="white" />
              <span style={{ fontSize: 24, color: "white" }}>{prodcond.timeExtremeLow.value}</span>
              <span className="card-unit">{prodcond.timeExtremeLow.unit}</span>
            </div>
          </div>
          <span className="card-description" style={{ marginTop: 4 }}>{prodcond.timeExtremeLast}</span>
        </Card>
      </div>

      {/* Tech list (desktop has it in a side column, we show below) */}
      <div style={{ marginBottom: 16 }}>
        {techListData.map(([k, v]) => (
          <ListRow key={k} label={k}>{v}</ListRow>
        ))}
      </div>

      {/* Charts */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 8, marginBottom: 16 }}>
        <PcfDonut pcf={pcf} />
        <MaterialsBar materials={materials} />
        {hazardousMaterial && (
          <Card heading="Hazardous material">
            <span className="card-heading">Hazardous material</span>
            <span>{hazardousMaterial}</span>
          </Card>
        )}
      </div>

      {/* Inline /// accent labels */}
      <div style={{ marginBottom: 16, display: "flex", flexWrap: "wrap", gap: 8 }}>
        {inlineData.map(([k, v]) => (
          <div key={k} style={{ fontSize: 14 }}>
            <span style={{ color: "var(--accent)", marginRight: 8 }}>/// {k}</span>
            <span>{v}</span>
          </div>
        ))}
      </div>

      {/* Submodel grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 8 }}>
        {submodelCells.map((c) => (
          <a key={c.key} onClick={() => onNavSubmodel(c.key)}
            style={{
              height: 50, width: "100%", background: "var(--primary)", borderRadius: 4,
              padding: "0 8px 0 16px", display: "flex", justifyContent: "space-between", alignItems: "center",
              fontSize: 20, fontWeight: 300, cursor: "pointer", color: "white",
            }}>
            {c.label}
            <Icon name="arrow_outward" size={20} color="var(--accent)" />
          </a>
        ))}
      </div>
    </div>
  );
}

window.SubmodelNav = SubmodelNav;
window.OverviewPage = OverviewPage;
window.MaterialsBar = MaterialsBar;
window.PcfDonut = PcfDonut;
