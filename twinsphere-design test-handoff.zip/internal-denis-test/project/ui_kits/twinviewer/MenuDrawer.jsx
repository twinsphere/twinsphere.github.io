function MenuDrawer({ open, onClose, language, onLanguageChange, onNav }) {
  if (!open) return null;
  return (
    <div
      onClick={onClose}
      style={{ position: "fixed", inset: 0, background: "#00000080", zIndex: 50, animation: "tw-fade 120ms ease-out" }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "white",
          width: 320,
          height: "100%",
          position: "absolute",
          left: 0,
          top: 0,
          borderTopRightRadius: 8,
          borderBottomRightRadius: 8,
          padding: "48px 16px 16px 8px",
          color: "var(--primary)",
          fontFamily: "var(--font-sans)",
          animation: "tw-slide-in 250ms linear",
          boxShadow: "4px 0 16px rgba(0,0,0,0.2)",
        }}
      >
        <button onClick={onClose}
          style={{ position: "absolute", right: 16, top: 16, background: "none", border: "none", cursor: "pointer", color: "#111" }}>
          <Icon name="close" size={22} color="#111" />
        </button>

        <section style={{ marginTop: 16 }}>
          <h3 className="section-title" style={{ textAlign: "right", margin: 0 }}>Open</h3>
          <div style={{ textAlign: "right" }}>
            <a onClick={() => { onClose(); onNav("scan"); }}
              style={{ height: 48, display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 16 }}>
              Scan QR Code <Icon name="qr_code" size={20} color="var(--primary)" />
            </a>
            <button onClick={() => { onClose(); /* open bookmarks */ }}
              style={{ height: 48, display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 8, cursor: "pointer", background: "none", border: "none", width: "100%", fontSize: 16, color: "var(--primary)" }}>
              Open Bookmarks <Icon name="bookmark" size={20} color="var(--primary)" />
            </button>
          </div>
        </section>

        <hr style={{ borderTop: "3px solid var(--border)", margin: "16px 0" }} />

        <section>
          <h3 className="section-title" style={{ textAlign: "right", margin: 0 }}>Language</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, marginTop: 8 }}>
            {["de", "en"].map((l) => (
              <label key={l} style={{ display: "flex", alignItems: "center", gap: 12, flexDirection: "row-reverse", cursor: "pointer" }}>
                <span>{l === "de" ? "German" : "English"}</span>
                <input type="radio" name="lang" checked={language === l} onChange={() => onLanguageChange(l)}
                  style={{ accentColor: "var(--primary)" }} />
              </label>
            ))}
          </div>
        </section>

        <hr style={{ borderTop: "3px solid var(--border)", margin: "16px 0" }} />
        <section><h3 className="section-title" style={{ textAlign: "right", margin: 0 }}>Tenant</h3></section>
        <hr style={{ borderTop: "3px solid var(--border)", margin: "16px 0" }} />
        <section><h3 className="section-title" style={{ textAlign: "right", margin: 0 }}>Actions</h3></section>
      </div>
    </div>
  );
}

window.MenuDrawer = MenuDrawer;
