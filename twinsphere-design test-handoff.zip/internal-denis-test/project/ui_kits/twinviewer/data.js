// Fake data mirroring the AAS submodel shape used in overview.html
export const twinData = {
  id: "PWR-PACK-7-2",
  techdata: {
    batteryCategory: "Lithium-Ion · Traction",
    manufacturerProductDesignation: "PowerPack 7.2 · OEM B-Series",
    manufacturerArticleNumber: "PP-7.2-C",
    companyLogo: null, // we draw a text wordmark instead
    productImages: null,
    batteryMass: { value: 120, unit: "kg" },
    nominalVoltage: { value: 48, unit: "V" },
    minVoltage: { value: 42, unit: "V" },
    maxVoltage: { value: 54.6, unit: "V" },
    ratedCapacity: { value: 87.4, unit: "kWh" },
    maxPermittedBatteryPower: { value: 240, unit: "kW" },
    tempRangeLower: { value: -20, unit: "°C" },
    tempRangeUpper: { value: 60, unit: "°C" },
    capThreshold: { value: 80, unit: "%" },
    warrantyPeriod: "5 years",
    expectedLifetimeInCalendarYears: "12 years",
    expectedNumberOfCycles: "3000 cycles",
  },
  nameplate: {
    manufacturerName: "Voltera Energy GmbH",
    serialNumber: "2024-A3F19",
    lifeCycleStage: "Operation / In-service",
    lifeTime: [1, 4, 12],
    dateOfPuttingIntoService: "Put into service 2024-12-08",
    facilityId: "DE.VOLT.PLANT-03",
    manufacturerId: "DE-VOLT-001",
    operatorId: "DE-OP-7781",
    dateOfManufacture: "2024-11-04",
    markings: [], // would be image URLs
  },
  prodcond: {
    stateOfCharge: { value: 87.4, unit: "%" },
    chargeLastUpdate: "Last updated 12 Apr 2026 · 09:14",
    remainingCap: { value: 81.6, unit: "kWh" },
    remainingLastUpdate: "Last updated 12 Apr 2026 · 09:14",
    numberOfFullCycles: 412,
    negativeEventText: "Over-temperature event · Cell group 4",
    negativeEventDate: "2026-02-17",
    timeExtremeHigh: { value: 42, unit: "min" },
    timeExtremeLow: { value: 8, unit: "min" },
    timeExtremeLast: "Since last reset",
  },
  pcf: [
    { name: "Raw materials", value: 212 },
    { name: "Manufacturing", value: 184 },
    { name: "Transport", value: 53 },
    { name: "Use phase", value: 22 },
    { name: "End of life", value: 16 },
  ],
  materials: [
    { name: "Nickel", mass: 28 },
    { name: "Cobalt", mass: 14 },
    { name: "Lithium", mass: 10 },
    { name: "Graphite", mass: 24 },
    { name: "Aluminum", mass: 18 },
    { name: "Copper", mass: 16 },
    { name: "Electrolyte", mass: 10 },
  ],
  hazardousMaterial: "Lithium hexafluorophosphate (LiPF6)",
};

export const bookmarks = [
  { id: "pwr-7-2", parsedId: "PWR-PACK-7-2", title: "PowerPack 7.2 · SN 2024-A3F19", description: "Lithium-Ion traction battery" },
  { id: "hv-xr", parsedId: "HV-PACK-XR-00218", title: "HV-Pack XR · SN 00218", description: "Stationary storage · 120 kWh" },
  { id: "gf-1", parsedId: "GRID-FLEX-1", title: "GridFlex 1 · SN 77-1123", description: "Grid-level buffer" },
];

export const submodelRoutes = [
  { key: "overview", label: "Overview" },
  { key: "nameplate", label: "Digital Nameplate" },
  { key: "handoverdoc", label: "Handover Documentation" },
  { key: "carbonfootprint", label: "Carbon Footprint" },
  { key: "technicaldata", label: "Technical Data" },
  { key: "productcondition", label: "Product Condition" },
  { key: "materialcomposition", label: "Material Composition" },
  { key: "circularity", label: "Circularity" },
];

export const pcfColorList = ["#C42E5F", "#017E97", "#54802E", "#4D4B9A", "#782235", "#18353D"];
export const materialsColorList = ["#C42E5F","#CF8D9A","#EFDBDE","#017E97","#8EACBC","#DAE2E8","#54802E","#A1AE7D","#E0E3D3","#4D4B9A","#918DC0","#DAD8EC","#782235","#A67D86","#E1D3D7","#18353D","#697179","#C7C9CD"];

Object.assign(window, { twinData, bookmarks, submodelRoutes, pcfColorList, materialsColorList });
