# Twinsphere Design System

This design system is built from the **Twinspector** product by **twinsphere** — a web viewer for Digital Twins and Digital Product Passports (DPPs, DBPs) based on the AAS (Asset Administration Shell) standard.

The product is styled as **twinviewer** (the PWA / UI branding), "powered by twinsphere" (the company). Users scan a QR code on a physical asset, which resolves to a Digital Twin containing nameplate, carbon footprint, technical data, product condition, material composition, handover docs, and circularity info.

## Sources

- **Codebase (ui):** `twinspector/ui/` — Angular 21 + Tailwind v4, ng-icons (Lucide + Material Icons outline & baseline), echarts + ngx-echarts, `@aas-core-works/aas-core3.0-typescript`. Components live under `src/app/common/components/**` and `src/app/modules/**`.
- **Codebase (backend):** `twinspector/backend/` — .NET services (Twinspector.Adapter.CloudTenantApi, Bpp, Core, Domain, RealtimeSync, Server). Not used for visual design.
- **App entry:** `src/app/app.html`, `src/styles.css`, `src/index.html`.
- **Dictionaries:** `src/app/modules/language/dictionaries/{en,de}.json` — the full English/German copy surface.

No Figma file, no slide decks, no explicit brand guide were provided. All visual decisions are reverse-engineered from the Angular source, which is the source of truth.

## Product context

Twinspector / twinviewer is a **mobile-first PWA** (max-width ~1024px but clamped to `max-w-5xl`) used by:

- **Field technicians / operators** — scanning a battery or piece of equipment in the field to see its digital nameplate, condition, warranty, last negative event.
- **Sustainability / compliance teams** — reading carbon footprint, hazardous materials, circularity info for a given asset.
- **Asset owners / managers** — bookmarking twins they look at often.

The flagship use case is the **Battery Passport** (EU Battery Regulation). Copy and submodels are heavy on: `batteryMass`, `stateOfCharge`, `remainingCapacity`, `numberOfFullCycles`, `lastNegativeEvent`, `nominalVoltage`, etc.

## Index

| File / folder | What's inside |
|---|---|
| `README.md` | This file. Start here. |
| `SKILL.md` | Agent-invocable skill entry point (Claude Code compatible). |
| `colors_and_type.css` | CSS variables — colors, typography, spacing, radii, shadows; semantic tokens (`h1`, `body`, `mono`). |
| `assets/` | Favicon, placeholder logos, marking sample images. |
| `fonts/` | Web fonts (or Google Font substitutions) used by the system. |
| `preview/` | Individual design-system cards (swatches, type specimens, components) used to populate the Design System tab. |
| `ui_kits/twinviewer/` | JSX recreation of the Twinviewer PWA: start screen, scan, overview (battery passport), submodel page. |

## Products represented

Only **one product** is represented in the source: the **Twinviewer PWA** (the Angular app). The backend is invisible to end users. So a single UI kit covers the surface.

## Content fundamentals

Short, functional, domain-specific. No marketing voice — the app is a utility.

- **Tone:** neutral, technical, factual. No first person. No exclamations. No emoji.
- **Capitalization:** Title Case for page titles ("Digital Nameplate", "Carbon Footprint", "Material Composition"). UPPERCASE for small section labels / field labels (`ART. NR.`, `SERIAL NR.`, `OVERALL CO2 EMISSION`, via `uppercase` + `text-sm`). Sentence case for help text.
- **Voice:** imperative for actions ("Scan QR Code", "Go to Overview", "Open Bookmarks"). Passive / stative for status ("Bookmark Added", "Automatic Refresh enabled", "Code recognized, trying to resolve Digital Twin...").
- **You / I:** avoided. Direct "you" only in onboarding hints ("You currently have no bookmarks. Visit a digital twin to add it as a bookmark.", "If the scan doesn't work, try reloading the page.").
- **Units:** always explicit, attached directly after the value: `120 kg`, `3.7 V`, `10000 km`. Units appear in a smaller/regular weight next to a larger numeric value on overview cards.
- **Numbers & IDs:** serial numbers, article numbers, warranty periods shown as-is; no prefixes other than the uppercase label. Accent color (green) used for inline field labels on the overview (`/// warranty period  5 years`).
- **Empty states:** italic, muted gray. Example: *"You currently have no bookmarks. Visit a digital twin to add it as a bookmark."*
- **Error states:** short, explanatory, no apology. "Twin not found" / "Scanned Code could not be resolved to a Twin."
- **Loading states:** lowercase with ellipsis `loading ...`, or a status line like "Code recognized, trying to resolve Digital Twin..."
- **Emoji:** never.
- **Domain terms — use verbatim:** *Digital Twin*, *Digital Nameplate*, *Carbon Footprint*, *Handover Documentation*, *Material Composition*, *Circularity*, *State of Charge*, *Product Condition*, *Asset Information*, *Tenant*.

## Visual foundations

### Palette
- **Background (page):** `#18353d` — very dark teal-green. The app is **dark by default**; there is no light mode.
- **Primary (card / raised surface):** `#2f4950` — slightly-lighter teal used for every card, pill, bookmark row, expandable row, chart frame.
- **Accent (interactive / highlight):** `#91c464` / `#93c664` — fresh leaf green. Used for the "twin" word in the wordmark, for clickable icons, for key figures (model name in overview), for labels like `/// warranty period`.
- **Alert / negative:** `#c42e5f` — magenta-crimson. Used in material/PCF charts as first color and for destructive/warn moments.
- **Gray (muted text):** `#97a4a7` — desaturated teal-gray. Field labels, meta text, secondary descriptions.
- **Border:** `#d3d8da` — very light gray, for dividers on white surfaces.
- **Background-light (inversion):** `#ffffff` — text on dark bg, and used as background for the mobile menu drawer, image cards (images sit on white), and a few modals.
- **Chart palettes:** two separate ordered lists (`materialsColorList`, `pcfColorList`) — rose/teal/olive/indigo/plum/black progression. See `colors_and_type.css`.

### Typography
- **Family:** system font stack — no custom webfont is loaded in the source. Browser default (likely Segoe UI / SF / Roboto) renders.
- **Substitution:** we use **Inter** via Google Fonts as the nearest neutral sans match. FLAG: if twinsphere has a specific brand font, please provide the files.
- **Wordmark:** `twin` in accent green, bold, followed by `viewer` in white, regular. `text-2xl`. Tagline: italic, `text-sm`, gray.
- **Scale (from Tailwind usage in the code):** text-xs (12), text-sm (14), text-base (16), text-lg (18), text-xl (20), text-2xl (24).
- **Weights observed:** 300 (thin — for the large "manufacturerProductDesignation" headline and the big submodel nav links), 400 regular, 500 medium, 600 semibold (section titles), 700 bold (wordmark "twin", small section titles, toast).
- **Casing:** uppercase for section titles / inline field labels (`text-sm font-bold uppercase`); Title Case for page titles; normal for body.
- **Line-height:** default / browser.

### Spacing & layout
- **Container:** `max-w-5xl` centered + `overflow-x-hidden`. App feels mobile-first even on desktop.
- **Scale:** 1 (4px), 2 (8px), 3 (12px), 4 (16px), 6 (24px), 8 (32px), 10 (40px), 12 (48px).
- **Card padding:** `p-4` or `py-2 px-4` inside overview cards.
- **Grid:** `md:grid-cols-3 md:gap-4` is the canonical overview layout.
- **Fixed elements:** Header at top (`pt-1 pb-3 pl-2`); toasts pinned with `fixed`; modals centered via `.centered-popover`.

### Radii
- **Cards / raised surfaces:** `rounded-md` (6px) or `rounded-sm` (2px) for chart frames; `rounded-lg`/`rounded-xl` only on drawer and the big scan CTA.
- **Buttons:** `rounded-md` (0.375rem).
- **Circular elements:** `rounded-full` for dismiss buttons in dialogs.

### Shadows & elevation
- Very minimal. The primary card uses **no shadow** — it's a flat color-block system relying on the primary/background contrast.
- The scan CTA on start screen uses `shadow-md` as the *only* shadow on the default surface.
- Modal backdrops use `bg-[#18353db3]` (70% alpha of bg) — darker wash, no blur.

### Borders
- Almost absent on cards. Used only on:
  - Image thumbnails: `border-2 border-white` (white frame on an otherwise dark page).
  - Toasts: `border-2 border-white`.
  - Outline button variant: `1px solid var(--border)`.
- Color-swatch legend chips in charts use a thin border.

### Backgrounds & imagery
- No hand-drawn illustrations, no gradients, no patterns, no textures. Deliberately plain.
- Imagery appears only as **real product images** or **company logos** surfaced inside a white panel (`bg-white flex items-center justify-center py-2`) — this white background is a *convention* for making variable-colored product photography readable on the dark page.
- `matImageNotSupported` icon shown as a placeholder when an image fails to load; always in muted gray on a light gray tile.
- Marking/regulatory badges (CE mark etc.) are shown as small `h-16` images on white in a wrapping row.

### Animations
- **Ease:** `ease-out` for entering, `ease-in` for leaving, ~150ms default duration. A few custom keyframes (sync spin 2s/1s, menu slide 250ms linear).
- **Sync icon:** rotates 360° and color-transitions from white to `--success` green on enable; reverses on disable (2s in / 1s out).
- **Accordion / expand-collapse:** animated via CSS grid-rows (`grid-template-rows: 1fr → 0fr`, 150ms).
- **Menu drawer (mobile):** slides in from `left: -100%` to 0 over 250ms linear; backdrop fades via its own `leavecontainer` keyframe.
- **Chart animations:** inherited from echarts defaults — quick `padAngle: 4` pie with no tooltip hover animations.
- **No bounces, no springy easing, no parallax.**

### Hover & press states
- **Default button (`.button.default`):** on hover, primary background mixes toward transparent by 10% (`color-mix(in srgb, var(--primary) 90%, transparent)`) — subtle darkening.
- **Ghost button (`.button.ghost`):** on hover swaps to white background + primary text — a full invert.
- **Icon buttons:** `opacity: 0.9` on hover.
- **Clickable cards / rows (bookmark, scan CTA):** `hover:opacity-90`.
- **Icons inside buttons:** the non-icon/sync buttons flip the `ng-icon` color to `--background` on hover.
- **Press:** not explicitly defined — browser default depression.
- **Focus-visible:** always a 2-ring: 2px gray inner + 2px background outer (makes the focus ring readable on dark bg).

### Transparency & blur
- Used sparingly. Modal backdrops use 50% primary or ~70% background, no backdrop-filter blur.
- Disabled items at `opacity-50` (bookmarks link when list is empty) or `text-white/60` (muted descriptions, disabled submodel nav items).
- Toast menu overlay at `#00000080`.

### Cards
- Flat `bg-(--primary)` tile, rounded, padded `p-4` for overview data cards — contain a small uppercase heading, a large primary data value (number + unit), a small gray description (timestamp), and an optional 40px icon anchored top-right.
- The "SubmodelElementCollection" expander card has a **2px wide accent stripe** of primary color running down the left gutter — not a traditional colored-border accent; visually it's the collapsible hint rail.
- Bookmark row: compact primary pill, accent-green bookmark icon + accent title + small muted description.

### Iconography
- **Material Icons** (`@ng-icons/material-icons/outline` and `/baseline`) for most app icons: QR, menu, bookmark, sync, close, arrow-drop-down, arrow-outward, dashboard, battery, schedule, event-busy, wb-sunny, ac-unit, device-thermostat, recent-actors, ev-station, info, warning, image-not-supported, expand-more, more-horiz, map/loupe, recent-actors, sync-outline. Rendered at 16–20px for inline, 40px for overview card icons, 64px for empty states and QR CTA.
- **Lucide** (`@ng-icons/lucide`) for generic UI: `lucideCopy`, `lucideCircleCheck`, `lucideCircleX`.
- **Material File Icons** (`@ng-icons/material-file-icons`) for file thumbnails: `matfPdfUncolored`, `matfFileUncolored`.
- No custom SVGs. No emoji. No unicode icons.
- Color: icons default to current text color (usually white). Interactive / accent icons use `text-(--accent)` (green). In chart legends, colored swatches are small filled `w-4 h-4` squares with `border-2 rounded-sm`.
- **Iconography direction in this design system:** we link Material Icons and Lucide from CDN (Material Symbols Outlined + lucide.min.js) and document usage — see `preview/icons-card.html` and `ui_kits/twinviewer/`.

---

## Next steps for the user

- Provide the actual font file if twinsphere has a brand typeface — currently using Inter as a placeholder.
- Provide a higher-resolution twinsphere logo — a wordmark-only version is reproduced in code but there's no logo file in the repo.
- Confirm the accent green hex — the codebase has both `#91c464` (start) and `#93c664` (success) in use side by side; we've standardised on `#91c464` as the canonical accent.
