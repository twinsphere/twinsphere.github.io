/* @ds-bundle: {"format":3,"namespace":"InternalDenisTest_c3a8f6","components":[],"sourceHashes":{"ui_kits/twinviewer/App.jsx":"bdcf6ee1c059","ui_kits/twinviewer/Bits.jsx":"e22294c59d0e","ui_kits/twinviewer/Header.jsx":"e24778cc4a1e","ui_kits/twinviewer/MenuDrawer.jsx":"cf91cc125c26","ui_kits/twinviewer/OverviewPage.jsx":"b5298621a48b","ui_kits/twinviewer/ScanPage.jsx":"fffa0f3bca36","ui_kits/twinviewer/StartPage.jsx":"d5ad4c672ff7","ui_kits/twinviewer/SubmodelPage.jsx":"5c1857fdb52d","ui_kits/twinviewer/data.js":"625d38fbe10b"},"inlinedExternals":[],"unexposedExports":[{"name":"bookmarks","sourcePath":"ui_kits/twinviewer/data.js"},{"name":"materialsColorList","sourcePath":"ui_kits/twinviewer/data.js"},{"name":"pcfColorList","sourcePath":"ui_kits/twinviewer/data.js"},{"name":"submodelRoutes","sourcePath":"ui_kits/twinviewer/data.js"},{"name":"twinData","sourcePath":"ui_kits/twinviewer/data.js"}]} */

(() => {

const __ds_ns = (window.InternalDenisTest_c3a8f6 = window.InternalDenisTest_c3a8f6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/twinviewer/App.jsx
try { (() => {
function App() {
  const [screen, setScreen] = React.useState("start"); // start | scan | overview | submodel
  const [route, setRoute] = React.useState("overview"); // submodel route key
  const [bookmarksState, setBookmarksState] = React.useState(bookmarks);
  const [bookmarkActive, setBookmarkActive] = React.useState(true);
  const [syncActive, setSyncActive] = React.useState(false);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [language, setLanguage] = React.useState("en");
  const [toast, setToast] = React.useState(null);
  function showToast(msg, type = "info") {
    setToast({
      msg,
      type
    });
    setTimeout(() => setToast(null), 2500);
  }
  function handleNav(target) {
    setScreen(target);
    if (target === "overview") setRoute("overview");
  }
  function handleOpenTwin(id) {
    setScreen("overview");
    setRoute("overview");
  }
  function handleOpenScan() {
    setScreen("scan");
  }
  function handleResolved(id) {
    setScreen("overview");
    setRoute("overview");
  }
  function handleNavSubmodel(key) {
    setScreen("submodel");
    setRoute(key);
  }
  function handleToOverview() {
    setScreen("overview");
    setRoute("overview");
  }
  function toggleBookmark() {
    setBookmarkActive(b => {
      showToast(!b ? "Bookmark Added" : "Bookmark Removed", "success");
      return !b;
    });
  }
  function toggleSync() {
    setSyncActive(s => {
      showToast(!s ? "Automatic Refresh enabled" : "Automatic Refresh disabled", "info");
      return !s;
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      background: "var(--bg-page)",
      color: "white",
      fontFamily: "var(--font-sans)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1024,
      margin: "0 auto",
      display: "flex",
      flexDirection: "column",
      minHeight: "100vh"
    }
  }, /*#__PURE__*/React.createElement(Header, {
    currentScreen: screen,
    onNav: handleNav,
    bookmarkActive: bookmarkActive,
    onToggleBookmark: toggleBookmark,
    syncActive: syncActive,
    onToggleSync: toggleSync,
    onOpenMenu: () => setMenuOpen(true)
  }), screen === "overview" || screen === "submodel" ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 16px 0 8px"
    }
  }, /*#__PURE__*/React.createElement(SubmodelNav, {
    active: route,
    routes: submodelRoutes,
    onNav: k => {
      if (k === "overview") handleToOverview();else handleNavSubmodel(k);
    }
  }), /*#__PURE__*/React.createElement("hr", {
    style: {
      border: "none",
      borderTop: "2px solid var(--primary)",
      margin: "0 16px 16px 0"
    }
  })) : null, /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1
    }
  }, screen === "start" && /*#__PURE__*/React.createElement(StartPage, {
    bookmarks: bookmarksState,
    onOpenScan: handleOpenScan,
    onOpenTwin: handleOpenTwin
  }), screen === "scan" && /*#__PURE__*/React.createElement(ScanPage, {
    onResolved: handleResolved
  }), screen === "overview" && /*#__PURE__*/React.createElement(OverviewPage, {
    twin: twinData,
    onNavSubmodel: handleNavSubmodel
  }), screen === "submodel" && /*#__PURE__*/React.createElement(SubmodelPage, {
    routeKey: route,
    twin: twinData,
    onGoOverview: handleToOverview
  })), /*#__PURE__*/React.createElement(MenuDrawer, {
    open: menuOpen,
    onClose: () => setMenuOpen(false),
    language: language,
    onLanguageChange: setLanguage,
    onNav: handleNav
  }), toast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      left: 0,
      right: 0,
      bottom: 24,
      display: "flex",
      justifyContent: "center",
      zIndex: 60,
      pointerEvents: "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: toast.type === "success" ? "#54802E" : toast.type === "alert" ? "#c42e5f" : "#2f4950",
      border: "2px solid white",
      borderRadius: 4,
      padding: "12px 16px",
      fontWeight: 500,
      fontSize: 14,
      maxWidth: 400,
      textAlign: "center"
    }
  }, toast.msg))));
}
window.App = App;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/twinviewer/Bits.jsx
try { (() => {
/** Shared UI primitives for Twinviewer kit */

function Icon({
  name,
  size = 20,
  color,
  outlined = false,
  className = ""
}) {
  const cls = outlined ? "material-icons-outlined" : "material-icons";
  return /*#__PURE__*/React.createElement("span", {
    className: `${cls} ${className}`,
    style: {
      fontSize: size,
      color,
      lineHeight: 1,
      verticalAlign: "middle",
      userSelect: "none"
    },
    "aria-hidden": "true"
  }, name);
}
function Card({
  heading,
  value,
  unit,
  description,
  icon,
  wide = false,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "tw-card",
    style: {
      background: "var(--bg-raised)",
      borderRadius: "var(--radius-md)",
      padding: "16px",
      position: "relative",
      display: "flex",
      flexDirection: "column",
      gap: "4px",
      gridColumn: wide ? "span 2" : undefined
    }
  }, heading && /*#__PURE__*/React.createElement("span", {
    className: "card-heading"
  }, heading), children ? children : /*#__PURE__*/React.createElement(React.Fragment, null, value !== undefined && /*#__PURE__*/React.createElement("span", {
    className: "card-data"
  }, value, unit ? /*#__PURE__*/React.createElement("span", {
    className: "card-unit",
    style: {
      marginLeft: 4
    }
  }, unit) : null), description && /*#__PURE__*/React.createElement("span", {
    className: "card-description"
  }, description)), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 14,
      bottom: 12,
      color: "white",
      opacity: 0.85
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 40
  })));
}
function ListRow({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      padding: "10px 0",
      borderBottom: "1px solid rgba(255,255,255,0.06)",
      fontSize: 14,
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "white",
      textAlign: "right"
    }
  }, children));
}
function ChartFrame({
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--bg-raised)",
      borderRadius: "var(--radius-xs)",
      padding: 8,
      display: "grid",
      gridTemplateRows: "max-content max-content max-content",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, title), children);
}
function AccentButton({
  icon,
  children,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    className: "btn icon-button md",
    style: {
      background: "var(--primary)",
      color: "white",
      border: "none",
      borderRadius: "var(--radius-md)",
      padding: "0 14px",
      height: 44,
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      fontSize: 16,
      cursor: "pointer"
    }
  }, icon && /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 20
  }), children);
}
function Divider() {
  return /*#__PURE__*/React.createElement("hr", {
    style: {
      border: "none",
      borderTop: "1px solid var(--primary)",
      margin: "0 16px 16px 0"
    }
  });
}
Object.assign(window, {
  Icon,
  Card,
  ListRow,
  ChartFrame,
  AccentButton,
  Divider
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/Bits.jsx", error: String((e && e.message) || e) }); }

// ui_kits/twinviewer/Header.jsx
try { (() => {
function Header({
  currentScreen,
  onNav,
  bookmarkActive,
  onToggleBookmark,
  syncActive,
  onToggleSync,
  onOpenMenu
}) {
  const showTwinActions = currentScreen === "overview" || currentScreen === "submodel";
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      width: "100%",
      padding: "4px 16px 12px 8px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn icon ghost",
    onClick: onOpenMenu,
    "aria-label": "Open menu",
    style: {
      background: "transparent",
      border: "none",
      cursor: "pointer",
      height: 36,
      width: 36
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "menu",
    color: "var(--accent)",
    size: 22
  })), /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav("start"),
    style: {
      fontSize: 24,
      lineHeight: 1,
      textDecoration: "none",
      color: "white",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)",
      fontWeight: 700
    }
  }, "twin"), "viewer"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontStyle: "italic",
      fontSize: 12,
      color: "#97a4a7",
      marginTop: 6,
      marginLeft: 2
    }
  }, "powered by twinsphere"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), showTwinActions && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
    className: "btn icon ghost",
    onClick: onToggleBookmark,
    style: {
      background: "transparent",
      border: "none",
      cursor: "pointer",
      height: 36,
      width: 36
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: bookmarkActive ? "bookmark" : "bookmark_border",
    outlined: !bookmarkActive,
    size: 20,
    color: bookmarkActive ? "var(--accent)" : "white"
  })), /*#__PURE__*/React.createElement("button", {
    className: "btn icon ghost",
    onClick: onToggleSync,
    title: "Enable/disable automatic refresh",
    style: {
      background: "transparent",
      border: "none",
      cursor: "pointer",
      height: 36,
      width: 36
    }
  }, /*#__PURE__*/React.createElement("span", {
    key: syncActive ? "on" : "off",
    style: {
      display: "inline-block",
      animation: `${syncActive ? "tw-sync-start 2s cubic-bezier(0,0,0.2,1)" : "tw-sync-stop 1s cubic-bezier(0,0,0.2,1)"}`,
      color: syncActive ? "var(--success)" : "white"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sync",
    outlined: true,
    size: 20,
    color: syncActive ? "var(--success)" : "white"
  })))));
}
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/twinviewer/MenuDrawer.jsx
try { (() => {
function MenuDrawer({
  open,
  onClose,
  language,
  onLanguageChange,
  onNav
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      background: "#00000080",
      zIndex: 50,
      animation: "tw-fade 120ms ease-out"
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "white",
      width: 320,
      height: "100%",
      position: "absolute",
      left: 0,
      top: 0,
      borderTopRightRadius: 8,
      borderBottomRightRadius: 8,
      padding: "48px 16px 16px 8px",
      color: "var(--primary)",
      fontFamily: "var(--font-sans)",
      animation: "tw-slide-in 250ms linear",
      boxShadow: "4px 0 16px rgba(0,0,0,0.2)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      position: "absolute",
      right: 16,
      top: 16,
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "#111"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "close",
    size: 22,
    color: "#111"
  })), /*#__PURE__*/React.createElement("section", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "section-title",
    style: {
      textAlign: "right",
      margin: 0
    }
  }, "Open"), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => {
      onClose();
      onNav("scan");
    },
    style: {
      height: 48,
      display: "flex",
      justifyContent: "flex-end",
      alignItems: "center",
      gap: 8,
      cursor: "pointer",
      fontSize: 16
    }
  }, "Scan QR Code ", /*#__PURE__*/React.createElement(Icon, {
    name: "qr_code",
    size: 20,
    color: "var(--primary)"
  })), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      onClose(); /* open bookmarks */
    },
    style: {
      height: 48,
      display: "flex",
      justifyContent: "flex-end",
      alignItems: "center",
      gap: 8,
      cursor: "pointer",
      background: "none",
      border: "none",
      width: "100%",
      fontSize: 16,
      color: "var(--primary)"
    }
  }, "Open Bookmarks ", /*#__PURE__*/React.createElement(Icon, {
    name: "bookmark",
    size: 20,
    color: "var(--primary)"
  })))), /*#__PURE__*/React.createElement("hr", {
    style: {
      borderTop: "3px solid var(--border)",
      margin: "16px 0"
    }
  }), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h3", {
    className: "section-title",
    style: {
      textAlign: "right",
      margin: 0
    }
  }, "Language"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4,
      marginTop: 8
    }
  }, ["de", "en"].map(l => /*#__PURE__*/React.createElement("label", {
    key: l,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexDirection: "row-reverse",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("span", null, l === "de" ? "German" : "English"), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: "lang",
    checked: language === l,
    onChange: () => onLanguageChange(l),
    style: {
      accentColor: "var(--primary)"
    }
  }))))), /*#__PURE__*/React.createElement("hr", {
    style: {
      borderTop: "3px solid var(--border)",
      margin: "16px 0"
    }
  }), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h3", {
    className: "section-title",
    style: {
      textAlign: "right",
      margin: 0
    }
  }, "Tenant")), /*#__PURE__*/React.createElement("hr", {
    style: {
      borderTop: "3px solid var(--border)",
      margin: "16px 0"
    }
  }), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h3", {
    className: "section-title",
    style: {
      textAlign: "right",
      margin: 0
    }
  }, "Actions"))));
}
window.MenuDrawer = MenuDrawer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/MenuDrawer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/twinviewer/OverviewPage.jsx
try { (() => {
function SubmodelNav({
  active,
  routes,
  onNav
}) {
  const [open, setOpen] = React.useState(false);
  const activeLabel = routes.find(r => r.key === active)?.label ?? "Overview";
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: "16px 0"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(v => !v),
    style: {
      width: "100%",
      textAlign: "left",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      background: "none",
      border: "none",
      color: "white",
      fontSize: 20,
      fontWeight: 300,
      textTransform: "uppercase"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "recent_actors",
    size: 20,
    color: "white",
    className: ""
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 16,
      flex: 1
    }
  }, activeLabel))), open && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      marginBottom: 16
    }
  }, routes.map(r => /*#__PURE__*/React.createElement("a", {
    key: r.key,
    onClick: () => {
      setOpen(false);
      onNav(r.key);
    },
    style: {
      marginLeft: 44,
      fontSize: 16,
      cursor: "pointer",
      color: active === r.key ? "var(--accent)" : "white",
      textTransform: "uppercase"
    }
  }, r.label)), /*#__PURE__*/React.createElement("a", {
    style: {
      marginLeft: 44,
      fontSize: 16,
      color: "rgba(255,255,255,0.6)",
      textTransform: "uppercase"
    }
  }, "Dummy 1"), /*#__PURE__*/React.createElement("a", {
    style: {
      marginLeft: 44,
      fontSize: 16,
      color: "rgba(255,255,255,0.6)",
      textTransform: "uppercase"
    }
  }, "Dummy 2")));
}
function MaterialsBar({
  materials
}) {
  const total = materials.reduce((a, b) => a + b.mass, 0);
  const sorted = [...materials].sort((a, b) => b.mass - a.mass);
  return /*#__PURE__*/React.createElement(ChartFrame, {
    title: "Material Composition"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      height: 40,
      margin: 8,
      borderRadius: 2,
      overflow: "hidden",
      border: "1px solid white"
    }
  }, sorted.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: m.name,
    style: {
      flex: m.mass,
      background: materialsColorList[i % materialsColorList.length],
      borderRight: i < sorted.length - 1 ? "1px solid white" : "none"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: 8
    }
  }, sorted.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: m.name,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginTop: 4,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      width: 16,
      height: 16,
      border: "2px solid white",
      borderRadius: 2,
      background: materialsColorList[i % materialsColorList.length]
    }
  }), /*#__PURE__*/React.createElement("span", null, m.name, " (", Math.round(m.mass / total * 100), " %)")))));
}
function PcfDonut({
  pcf
}) {
  const total = pcf.reduce((a, b) => a + b.value, 0);
  // build the stroke-dasharray segments around a circle
  const radius = 70;
  const circ = 2 * Math.PI * radius;
  let offset = 0;
  const segments = pcf.map((p, i) => {
    const frac = p.value / total;
    const seg = {
      color: pcfColorList[i % pcfColorList.length],
      dash: `${circ * frac - 6} ${circ}`,
      offset: -offset
    };
    offset += circ * frac;
    return seg;
  });
  return /*#__PURE__*/React.createElement(ChartFrame, {
    title: "Carbon Footprint"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 240,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "-100 -100 200 200",
    width: "200",
    height: "200",
    style: {
      transform: "rotate(-90deg)"
    }
  }, segments.map((s, i) => /*#__PURE__*/React.createElement("circle", {
    key: i,
    r: radius,
    fill: "none",
    stroke: s.color,
    strokeWidth: 26,
    strokeDasharray: s.dash,
    strokeDashoffset: s.offset
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 42,
      color: "white",
      lineHeight: 1
    }
  }, total), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: "white"
    }
  }, "CO", /*#__PURE__*/React.createElement("sub", null, "2"), "eq"))), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: 8
    }
  }, pcf.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: p.name,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginTop: 4,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      width: 16,
      height: 16,
      border: "2px solid white",
      borderRadius: 2,
      background: pcfColorList[i % pcfColorList.length]
    }
  }), /*#__PURE__*/React.createElement("span", null, p.name, " (", Math.round(p.value / total * 100), " %)")))));
}
function OverviewPage({
  twin,
  onNavSubmodel
}) {
  const {
    techdata,
    nameplate,
    prodcond,
    pcf,
    materials,
    hazardousMaterial
  } = twin;
  const totalPcf = pcf.reduce((a, b) => a + b.value, 0);
  const techListData = [["Battery mass", `${techdata.batteryMass.value} ${techdata.batteryMass.unit}`], ["Nominal voltage", `${techdata.nominalVoltage.value} ${techdata.nominalVoltage.unit}`], ["Min voltage", `${techdata.minVoltage.value} ${techdata.minVoltage.unit}`], ["Max voltage", `${techdata.maxVoltage.value} ${techdata.maxVoltage.unit}`], ["Rated capacity", `${techdata.ratedCapacity.value} ${techdata.ratedCapacity.unit}`], ["Max. permitted battery power", `${techdata.maxPermittedBatteryPower.value} ${techdata.maxPermittedBatteryPower.unit}`], ["Temperature range", `${techdata.tempRangeLower.value} ${techdata.tempRangeLower.unit} to ${techdata.tempRangeUpper.value} ${techdata.tempRangeUpper.unit}`], ["Capacity threshold exhaustion", `${techdata.capThreshold.value} ${techdata.capThreshold.unit}`]];
  const inlineData = [["unique facility identifier", nameplate.facilityId], ["manufacturer identifier", nameplate.manufacturerId], ["operator identifier", nameplate.operatorId], ["warranty period", techdata.warrantyPeriod], ["expected lifetime in years", techdata.expectedLifetimeInCalendarYears], ["date of manufacture", nameplate.dateOfManufacture]];
  const submodelCells = [{
    key: "nameplate",
    label: "Digital Nameplate"
  }, {
    key: "handoverdoc",
    label: "Handover Documentation"
  }, {
    key: "carbonfootprint",
    label: "Carbon Footprint"
  }, {
    key: "technicaldata",
    label: "Technical Data"
  }, {
    key: "productcondition",
    label: "Product Condition"
  }, {
    key: "materialcomposition",
    label: "Material Composition"
  }, {
    key: "circularity",
    label: "Circularity"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 16px 32px 8px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr",
      gap: 16,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 500,
      color: "var(--accent)"
    }
  }, techdata.batteryCategory), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 300,
      color: "var(--accent)"
    }
  }, techdata.manufacturerProductDesignation)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 500,
      fontSize: 16,
      marginBottom: 8
    }
  }, nameplate.manufacturerName), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--gray)",
      marginRight: 8,
      textTransform: "uppercase"
    }
  }, "Art. nr."), /*#__PURE__*/React.createElement("span", null, techdata.manufacturerArticleNumber)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--gray)",
      marginRight: 8,
      textTransform: "uppercase"
    }
  }, "Serial nr."), /*#__PURE__*/React.createElement("span", null, nameplate.serialNumber)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--gray)",
      marginRight: 8,
      textTransform: "uppercase"
    }
  }, "Overall CO2 emission"), /*#__PURE__*/React.createElement("span", null, totalPcf, " CO2eq")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--gray)",
      marginRight: 8,
      textTransform: "uppercase"
    }
  }, "Lifecycle state"), /*#__PURE__*/React.createElement("span", null, nameplate.lifeCycleStage)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 8,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    wide: true,
    heading: "Current Lifetime in Service",
    icon: "schedule",
    description: nameplate.dateOfPuttingIntoService
  }, /*#__PURE__*/React.createElement("span", {
    className: "card-heading"
  }, "Current Lifetime in Service"), /*#__PURE__*/React.createElement("span", {
    className: "card-data"
  }, nameplate.lifeTime[0], " ", /*#__PURE__*/React.createElement("span", {
    className: "card-unit"
  }, "years"), " ", nameplate.lifeTime[1], " ", /*#__PURE__*/React.createElement("span", {
    className: "card-unit"
  }, "months"), " ", nameplate.lifeTime[2], " ", /*#__PURE__*/React.createElement("span", {
    className: "card-unit"
  }, "days")), /*#__PURE__*/React.createElement("span", {
    className: "card-description"
  }, nameplate.dateOfPuttingIntoService)), /*#__PURE__*/React.createElement(Card, {
    heading: "State of Charge",
    value: prodcond.stateOfCharge.value,
    unit: prodcond.stateOfCharge.unit,
    description: prodcond.chargeLastUpdate,
    icon: "battery_5_bar"
  }), /*#__PURE__*/React.createElement(Card, {
    heading: "Remaining Capacity",
    value: prodcond.remainingCap.value,
    unit: prodcond.remainingCap.unit,
    description: prodcond.remainingLastUpdate,
    icon: "battery_charging_full"
  }), /*#__PURE__*/React.createElement(Card, {
    wide: true,
    heading: "Number of Full Cycles",
    value: prodcond.numberOfFullCycles,
    description: `Expected: ${techdata.expectedNumberOfCycles}`,
    icon: "ev_station"
  }), /*#__PURE__*/React.createElement(Card, {
    wide: true,
    heading: "Last Negative Event",
    icon: "event_busy"
  }, /*#__PURE__*/React.createElement("span", {
    className: "card-heading"
  }, "Last Negative Event"), /*#__PURE__*/React.createElement("span", {
    className: "card-data",
    style: {
      fontSize: 18
    }
  }, prodcond.negativeEventText), /*#__PURE__*/React.createElement("span", {
    className: "card-description"
  }, prodcond.negativeEventDate)), /*#__PURE__*/React.createElement(Card, {
    wide: true,
    heading: "Time Extreme Temp Charging",
    icon: "device_thermostat"
  }, /*#__PURE__*/React.createElement("span", {
    className: "card-heading"
  }, "Time Extreme Temp Charging"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      alignItems: "flex-end",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 4,
      minWidth: 120
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "wb_sunny",
    size: 18,
    color: "white"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 24,
      color: "white"
    }
  }, prodcond.timeExtremeHigh.value), /*#__PURE__*/React.createElement("span", {
    className: "card-unit"
  }, prodcond.timeExtremeHigh.unit)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "ac_unit",
    size: 18,
    color: "white"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 24,
      color: "white"
    }
  }, prodcond.timeExtremeLow.value), /*#__PURE__*/React.createElement("span", {
    className: "card-unit"
  }, prodcond.timeExtremeLow.unit))), /*#__PURE__*/React.createElement("span", {
    className: "card-description",
    style: {
      marginTop: 4
    }
  }, prodcond.timeExtremeLast))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, techListData.map(([k, v]) => /*#__PURE__*/React.createElement(ListRow, {
    key: k,
    label: k
  }, v))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr",
      gap: 8,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(PcfDonut, {
    pcf: pcf
  }), /*#__PURE__*/React.createElement(MaterialsBar, {
    materials: materials
  }), hazardousMaterial && /*#__PURE__*/React.createElement(Card, {
    heading: "Hazardous material"
  }, /*#__PURE__*/React.createElement("span", {
    className: "card-heading"
  }, "Hazardous material"), /*#__PURE__*/React.createElement("span", null, hazardousMaterial))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16,
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, inlineData.map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)",
      marginRight: 8
    }
  }, "/// ", k), /*#__PURE__*/React.createElement("span", null, v)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr",
      gap: 8
    }
  }, submodelCells.map(c => /*#__PURE__*/React.createElement("a", {
    key: c.key,
    onClick: () => onNavSubmodel(c.key),
    style: {
      height: 50,
      width: "100%",
      background: "var(--primary)",
      borderRadius: 4,
      padding: "0 8px 0 16px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontSize: 20,
      fontWeight: 300,
      cursor: "pointer",
      color: "white"
    }
  }, c.label, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow_outward",
    size: 20,
    color: "var(--accent)"
  })))));
}
window.SubmodelNav = SubmodelNav;
window.OverviewPage = OverviewPage;
window.MaterialsBar = MaterialsBar;
window.PcfDonut = PcfDonut;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/OverviewPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/twinviewer/ScanPage.jsx
try { (() => {
function ScanPage({
  onResolved
}) {
  const [loading, setLoading] = React.useState(false);
  React.useEffect(() => {
    // simulate QR being detected after a bit
    const t = setTimeout(() => {
      setLoading(true);
      const t2 = setTimeout(() => onResolved("PWR-PACK-7-2"), 1400);
      return () => clearTimeout(t2);
    }, 1800);
    return () => clearTimeout(t);
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      alignItems: "center",
      padding: "16px 16px 16px 8px",
      position: "relative",
      minHeight: 500
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      maxWidth: 720,
      aspectRatio: "4 / 3",
      background: "linear-gradient(135deg, #0f2226 0%, #1a4048 100%)",
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      backgroundImage: "radial-gradient(circle at 40% 60%, rgba(255,255,255,0.08), transparent 40%), radial-gradient(circle at 75% 30%, rgba(145,196,100,0.06), transparent 50%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: 200,
      height: 200,
      border: "2px solid rgba(255,255,255,0.5)"
    }
  }, ["tl", "tr", "bl", "br"].map(c => /*#__PURE__*/React.createElement("span", {
    key: c,
    style: {
      position: "absolute",
      [c.startsWith("t") ? "top" : "bottom"]: -2,
      [c.endsWith("l") ? "left" : "right"]: -2,
      width: 36,
      height: 36,
      borderTop: c.startsWith("t") ? "4px solid var(--accent)" : undefined,
      borderBottom: c.startsWith("b") ? "4px solid var(--accent)" : undefined,
      borderLeft: c.endsWith("l") ? "4px solid var(--accent)" : undefined,
      borderRight: c.endsWith("r") ? "4px solid var(--accent)" : undefined
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      maxWidth: 720,
      display: "flex",
      alignItems: "center",
      marginTop: 16,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "info",
    size: 20,
    color: "white"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      marginLeft: 8,
      marginBlock: 0
    }
  }, "If the scan doesn't work, try reloading the page.")), loading && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(47,73,80,0.5)",
      zIndex: 40,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "white",
      borderRadius: "var(--radius-md)",
      padding: "16px 32px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 16,
      maxWidth: "90%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 24,
      height: 24,
      borderRadius: "50%",
      border: "6px solid var(--accent)",
      borderRightColor: "var(--primary)",
      animation: "tw-spin 1s linear infinite"
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--primary)",
      fontWeight: 600,
      margin: 0
    }
  }, "Code recognized, trying to resolve Digital Twin..."))));
}
window.ScanPage = ScanPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/ScanPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/twinviewer/StartPage.jsx
try { (() => {
function StartPage({
  bookmarks,
  onOpenScan,
  onOpenTwin
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100%",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 40,
      padding: "24px 32px 24px 24px"
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: onOpenScan,
    "aria-label": "Scan QR Code",
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 12,
      background: "var(--primary)",
      color: "white",
      borderRadius: 16,
      padding: 32,
      boxShadow: "0 4px 6px -1px rgba(0,0,0,0.3), 0 2px 4px -2px rgba(0,0,0,0.25)",
      cursor: "pointer",
      transition: "opacity 200ms"
    },
    onMouseDown: e => e.currentTarget.style.opacity = "0.9",
    onMouseUp: e => e.currentTarget.style.opacity = "1",
    onMouseLeave: e => e.currentTarget.style.opacity = "1"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "qr_code",
    size: 64,
    color: "white"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 600
    }
  }, "Scan QR Code")), /*#__PURE__*/React.createElement("section", {
    style: {
      width: "100%",
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      color: "var(--accent)",
      fontSize: 14,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.04em",
      margin: 0
    }
  }, "Recent Bookmarks"), /*#__PURE__*/React.createElement("button", {
    disabled: !bookmarks.length,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      color: bookmarks.length ? "white" : "var(--gray)",
      textDecoration: "underline",
      background: "none",
      border: "none",
      cursor: "pointer",
      fontSize: 14,
      opacity: bookmarks.length ? 1 : 0.5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bookmark",
    size: 16,
    color: bookmarks.length ? "white" : "var(--gray)"
  }), "Open Bookmarks")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, bookmarks.length === 0 ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontStyle: "italic",
      color: "var(--gray)",
      margin: 0
    }
  }, "You currently have no bookmarks. Visit a digital twin to add it as a bookmark.") : bookmarks.map(b => /*#__PURE__*/React.createElement("a", {
    key: b.id,
    onClick: () => onOpenTwin(b.parsedId),
    style: {
      background: "var(--primary)",
      borderRadius: "var(--radius-md)",
      padding: "12px 16px",
      display: "flex",
      alignItems: "center",
      gap: 12,
      cursor: "pointer",
      transition: "opacity 200ms"
    },
    onMouseOver: e => e.currentTarget.style.opacity = "0.92",
    onMouseOut: e => e.currentTarget.style.opacity = "1"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bookmark",
    size: 20,
    color: "var(--accent)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--accent)",
      fontWeight: 400
    }
  }, b.title), b.description && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      opacity: 0.75
    }
  }, b.description)))))));
}
window.StartPage = StartPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/StartPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/twinviewer/SubmodelPage.jsx
try { (() => {
function PropertyRow({
  label,
  children,
  definition
}) {
  const [open, setOpen] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "6px 12px 8px",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => definition && setOpen(v => !v),
    style: {
      color: "var(--accent)",
      fontSize: 13,
      fontWeight: 700,
      display: "flex",
      gap: 6,
      alignItems: "center",
      cursor: definition ? "pointer" : "default"
    }
  }, label, definition && /*#__PURE__*/React.createElement(Icon, {
    name: "arrow_drop_down",
    size: 18,
    color: "var(--accent)",
    className: open ? "rot" : ""
  })), definition && open && /*#__PURE__*/React.createElement("div", {
    style: {
      fontStyle: "italic",
      color: "var(--gray)",
      marginTop: 4,
      fontSize: 13
    }
  }, definition), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      marginTop: 2
    }
  }, children));
}
function CollectionBlock({
  title,
  children,
  defaultOpen = true
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 8,
      background: "var(--primary)",
      borderRadius: 6,
      minHeight: "100%"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(v => !v),
    style: {
      background: "var(--primary)",
      border: "none",
      borderRadius: 6,
      width: "100%",
      height: 44,
      color: "white",
      padding: "0 12px",
      fontSize: 16,
      textAlign: "left",
      display: "flex",
      alignItems: "center",
      gap: 8,
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "expand_more",
    size: 20,
    className: open ? "rot" : ""
  }), title), open && /*#__PURE__*/React.createElement("div", null, children)));
}
function SubmodelPage({
  routeKey,
  twin,
  onGoOverview
}) {
  // Render something different per route using the twin data.
  const routeContent = {
    nameplate: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Asset Information"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Asset Kind",
      definition: "Describes if an element is a type or an instance."
    }, "Instance"), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Global Asset ID"
    }, "urn:voltera:powerpack:", twin.id), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Version"
    }, "1.2.0")), /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Manufacturer"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Manufacturer name"
    }, twin.nameplate.manufacturerName), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Manufacturer identifier"
    }, twin.nameplate.manufacturerId), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Date of manufacture"
    }, twin.nameplate.dateOfManufacture)), /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Serial & Article"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Serial number"
    }, twin.nameplate.serialNumber), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Article number"
    }, twin.techdata.manufacturerArticleNumber), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Operator identifier"
    }, twin.nameplate.operatorId))),
    technicaldata: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Electrical"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Nominal voltage",
      definition: "Nominal output voltage under standard load."
    }, twin.techdata.nominalVoltage.value, " ", twin.techdata.nominalVoltage.unit), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Min voltage"
    }, twin.techdata.minVoltage.value, " ", twin.techdata.minVoltage.unit), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Max voltage"
    }, twin.techdata.maxVoltage.value, " ", twin.techdata.maxVoltage.unit), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Rated capacity"
    }, twin.techdata.ratedCapacity.value, " ", twin.techdata.ratedCapacity.unit), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Max. permitted battery power"
    }, twin.techdata.maxPermittedBatteryPower.value, " ", twin.techdata.maxPermittedBatteryPower.unit)), /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Environmental"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Temperature range"
    }, twin.techdata.tempRangeLower.value, " ", twin.techdata.tempRangeLower.unit, " to ", twin.techdata.tempRangeUpper.value, " ", twin.techdata.tempRangeUpper.unit), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Capacity threshold exhaustion"
    }, twin.techdata.capThreshold.value, " ", twin.techdata.capThreshold.unit))),
    carbonfootprint: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Product Carbon Footprint"
    }, twin.pcf.map(p => /*#__PURE__*/React.createElement(PropertyRow, {
      key: p.name,
      label: p.name
    }, p.value, " CO2eq"))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 16
      }
    }, /*#__PURE__*/React.createElement(PcfDonut, {
      pcf: twin.pcf
    }))),
    materialcomposition: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 16
      }
    }, /*#__PURE__*/React.createElement(MaterialsBar, {
      materials: twin.materials
    })), /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Battery materials"
    }, twin.materials.map(m => /*#__PURE__*/React.createElement(PropertyRow, {
      key: m.name,
      label: m.name
    }, m.mass, " kg"))), /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Hazardous",
      defaultOpen: false
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Hazardous material"
    }, twin.hazardousMaterial))),
    productcondition: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Status"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "State of charge"
    }, twin.prodcond.stateOfCharge.value, " ", twin.prodcond.stateOfCharge.unit), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Remaining capacity"
    }, twin.prodcond.remainingCap.value, " ", twin.prodcond.remainingCap.unit), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Number of full cycles"
    }, twin.prodcond.numberOfFullCycles)), /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Events"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Last negative event"
    }, twin.prodcond.negativeEventText), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Negative event date"
    }, twin.prodcond.negativeEventDate))),
    handoverdoc: /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "Documents"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "User manual"
    }, "Voltera_PowerPack7.2_Manual.pdf"), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Installation guide"
    }, "Voltera_PowerPack7.2_Install.pdf"), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Declaration of conformity"
    }, "CE_DoC_2024.pdf")),
    circularity: /*#__PURE__*/React.createElement(CollectionBlock, {
      title: "End-of-life & recyclability"
    }, /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Recyclability rate"
    }, "92 %"), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Disassembly instructions available"
    }, "Yes"), /*#__PURE__*/React.createElement(PropertyRow, {
      label: "Take-back contact"
    }, "recycle@voltera.example"))
  }[routeKey] ?? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      color: "var(--gray)"
    }
  }, "No content.");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 16px 32px 8px"
    }
  }, /*#__PURE__*/React.createElement(AccentButton, {
    icon: "dashboard",
    onClick: onGoOverview
  }, "Go to Overview"), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 16
    }
  }), routeContent);
}
window.SubmodelPage = SubmodelPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/SubmodelPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/twinviewer/data.js
try { (() => {
// Fake data mirroring the AAS submodel shape used in overview.html
const twinData = {
  id: "PWR-PACK-7-2",
  techdata: {
    batteryCategory: "Lithium-Ion · Traction",
    manufacturerProductDesignation: "PowerPack 7.2 · OEM B-Series",
    manufacturerArticleNumber: "PP-7.2-C",
    companyLogo: null,
    // we draw a text wordmark instead
    productImages: null,
    batteryMass: {
      value: 120,
      unit: "kg"
    },
    nominalVoltage: {
      value: 48,
      unit: "V"
    },
    minVoltage: {
      value: 42,
      unit: "V"
    },
    maxVoltage: {
      value: 54.6,
      unit: "V"
    },
    ratedCapacity: {
      value: 87.4,
      unit: "kWh"
    },
    maxPermittedBatteryPower: {
      value: 240,
      unit: "kW"
    },
    tempRangeLower: {
      value: -20,
      unit: "°C"
    },
    tempRangeUpper: {
      value: 60,
      unit: "°C"
    },
    capThreshold: {
      value: 80,
      unit: "%"
    },
    warrantyPeriod: "5 years",
    expectedLifetimeInCalendarYears: "12 years",
    expectedNumberOfCycles: "3000 cycles"
  },
  nameplate: {
    manufacturerName: "Voltera Energy GmbH",
    serialNumber: "2024-A3F19",
    lifeCycleStage: "Operation / In-service",
    lifeTime: [1, 4, 12],
    dateOfPuttingIntoService: "Put into service 2024-12-08",
    facilityId: "DE.VOLT.PLANT-03",
    manufacturerId: "DE-VOLT-001",
    operatorId: "DE-OP-7781",
    dateOfManufacture: "2024-11-04",
    markings: [] // would be image URLs
  },
  prodcond: {
    stateOfCharge: {
      value: 87.4,
      unit: "%"
    },
    chargeLastUpdate: "Last updated 12 Apr 2026 · 09:14",
    remainingCap: {
      value: 81.6,
      unit: "kWh"
    },
    remainingLastUpdate: "Last updated 12 Apr 2026 · 09:14",
    numberOfFullCycles: 412,
    negativeEventText: "Over-temperature event · Cell group 4",
    negativeEventDate: "2026-02-17",
    timeExtremeHigh: {
      value: 42,
      unit: "min"
    },
    timeExtremeLow: {
      value: 8,
      unit: "min"
    },
    timeExtremeLast: "Since last reset"
  },
  pcf: [{
    name: "Raw materials",
    value: 212
  }, {
    name: "Manufacturing",
    value: 184
  }, {
    name: "Transport",
    value: 53
  }, {
    name: "Use phase",
    value: 22
  }, {
    name: "End of life",
    value: 16
  }],
  materials: [{
    name: "Nickel",
    mass: 28
  }, {
    name: "Cobalt",
    mass: 14
  }, {
    name: "Lithium",
    mass: 10
  }, {
    name: "Graphite",
    mass: 24
  }, {
    name: "Aluminum",
    mass: 18
  }, {
    name: "Copper",
    mass: 16
  }, {
    name: "Electrolyte",
    mass: 10
  }],
  hazardousMaterial: "Lithium hexafluorophosphate (LiPF6)"
};
const bookmarks = [{
  id: "pwr-7-2",
  parsedId: "PWR-PACK-7-2",
  title: "PowerPack 7.2 · SN 2024-A3F19",
  description: "Lithium-Ion traction battery"
}, {
  id: "hv-xr",
  parsedId: "HV-PACK-XR-00218",
  title: "HV-Pack XR · SN 00218",
  description: "Stationary storage · 120 kWh"
}, {
  id: "gf-1",
  parsedId: "GRID-FLEX-1",
  title: "GridFlex 1 · SN 77-1123",
  description: "Grid-level buffer"
}];
const submodelRoutes = [{
  key: "overview",
  label: "Overview"
}, {
  key: "nameplate",
  label: "Digital Nameplate"
}, {
  key: "handoverdoc",
  label: "Handover Documentation"
}, {
  key: "carbonfootprint",
  label: "Carbon Footprint"
}, {
  key: "technicaldata",
  label: "Technical Data"
}, {
  key: "productcondition",
  label: "Product Condition"
}, {
  key: "materialcomposition",
  label: "Material Composition"
}, {
  key: "circularity",
  label: "Circularity"
}];
const pcfColorList = ["#C42E5F", "#017E97", "#54802E", "#4D4B9A", "#782235", "#18353D"];
const materialsColorList = ["#C42E5F", "#CF8D9A", "#EFDBDE", "#017E97", "#8EACBC", "#DAE2E8", "#54802E", "#A1AE7D", "#E0E3D3", "#4D4B9A", "#918DC0", "#DAD8EC", "#782235", "#A67D86", "#E1D3D7", "#18353D", "#697179", "#C7C9CD"];
Object.assign(window, {
  twinData,
  bookmarks,
  submodelRoutes,
  pcfColorList,
  materialsColorList
});
Object.assign(__ds_scope, { twinData, bookmarks, submodelRoutes, pcfColorList, materialsColorList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/twinviewer/data.js", error: String((e && e.message) || e) }); }

})();
