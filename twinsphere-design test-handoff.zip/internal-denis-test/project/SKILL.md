---
name: twinsphere-design
description: Use this skill to generate well-branded interfaces and assets for twinsphere (Twinspector / Twinviewer), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## What this skill contains

- `README.md` — brand foundations, content rules, visual rules, iconography.
- `colors_and_type.css` — CSS variables for colors, semantic text, type scale, spacing, radii, motion; plus semantic classes (h1, h2, card-heading, tw-card, etc).
- `assets/` — favicon and any logo/marking placeholders.
- `preview/` — small preview cards for each foundation and component (swatches, type specimens, buttons, cards, icons).
- `ui_kits/twinviewer/` — React recreation of the Twinviewer PWA: start, scan, battery passport overview, submodel pages.
